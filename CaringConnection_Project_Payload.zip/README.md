# Caring Connection Android Test App

This is an Android Studio project that wraps the working Caring Connection app
into a normal Android application using a WebView.

## What works
- App icon and normal Android launcher
- Full-screen app experience
- Members
- Monthly collections
- Donations
- Help / expense entries
- Ledger
- Reports
- Local on-device storage through WebView localStorage
- Offline operation after installation

## Build the APK in Android Studio
1. Install Android Studio on Windows/Mac.
2. Extract this ZIP.
3. Open the `CaringConnection_AndroidStudio` folder.
4. Let Android Studio download/sync Gradle dependencies.
5. Choose: Build > Build App Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will normally be created at:
   `app/build/outputs/apk/debug/app-debug.apk`
7. Copy that APK to your Android phone and install it.

If Android blocks installation, enable "Install unknown apps" for the app you
used to open the APK (for example Files or Chrome).

## Important
This is a local test build. It does NOT yet have:
- Cloud database
- Multiple users
- Admin/Treasurer permissions
- Server-side backup
- Secure authentication

Those should be added before real foundation use.
