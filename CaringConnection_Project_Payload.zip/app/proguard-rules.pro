# No custom rules needed for test build.
